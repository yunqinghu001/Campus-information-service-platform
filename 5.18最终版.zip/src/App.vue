<template>
  <router-view/>
</template>

<style>
@import './assets/css/reset.css'

</style>

