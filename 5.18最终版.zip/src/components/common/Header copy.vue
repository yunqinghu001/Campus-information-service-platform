<template>
    <div class="common-layout">
        <el-container>
            <el-header>
                <router-link to="/">
                    <el-button type="primary" style="width: 300px;height: 60px;font-size: larger;">主页</el-button>
                </router-link>
            </el-header>
            <el-main>
                <router-link to="/ClassTable"><el-button type="primary">课表</el-button></router-link>
                <router-link to="/About"><el-button type="success">个人介绍</el-button></router-link>
                <router-link to="/Info"><el-button type="info">课程介绍</el-button></router-link>
            </el-main>
        </el-container>
    </div>
</template>
