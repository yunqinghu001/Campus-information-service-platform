<template onload="On1()">
  <div onload="getweek()">
    <div id="app" class="wrap">
      <ul class="weather_list">
        <li v-for="item in info">
          <div class="info_time"><span class="iconfont">{{ item.fxDate }}</span></div>
          <div class="info_type"><span>{{ item.textDay }}</span></div>
          <div class="info_temp">
            <b class="low">{{ item.tempMin }}°C</b> ~<b class="high"> {{ item.tempMax }}°C</b>
          </div>
        </li>
      </ul>
    </div>
    <div id="div1">
      <table>
        <caption>2025上梁其洋的课表(<a href="#" onclick="openWin()">教学安排</a>)</caption>
        <!--第1行-->
        <tr>
          <th style="background-color:white"></th>
          <th>周一</th>
          <th>周二</th>
          <th>周三</th>
          <th>周四</th>
          <th>周五</th>
        </tr>
        <!--第2行 1节-->
        <tr>
          <td class="td1">
            1<br />
            8:00~8:45
          </td>
          <!--周一-->
          <td>&#128516 </td>
          <!--周二-->
          <td>&#128516 </td>
          <!--周三-->
          <td>&#128516 </td>
          <!--周四-->
          <td rowspan=2>
            <el-link href="../../public/C语言程序设计_厦门大学数据库实验室.html"> C#程序设计</el-link>(121-124)
           <br />2-10,12-14周<br />教1-210 </td>
          <!--周五-->
          <td>&#128516 </td>
        </tr>
        <!--第3行 2节-->
        <tr>
          <td class="td1">
            2 <br />
            8:55~9:40
          </td>
          <!--周一-->
          <td> &#128516 </td>
          <!--周二--> 
          <td> &#128516 </td>
          <!--周三-->
          <td> &#128516 </td>
          <!--周五-->
          <td> &#128516 </td>
        </tr>
        <!--第4行 3节-->
        <tr>
          <td class="td1">
            3 <br />
            10:10~10:55
          </td>
          <!--周一-->
          <td rowspan=2 class="c121"> 数字化素养<br />1-15周(单) 教1-210<br />2-16周(双)<br />三园区5-304</td>
          <!--周二-->
          <td rowspan=2 class="c941"> 数据库基础<br />1-19周 教1-206 <br /> </td>
          <!--周三-->
          <td> 😃 </td>
          <!--周四-->
          <td rowspan=2> C#程序设计(121/2)<br />2-10,12-14周<br />云实验</td>
          <!--周五-->
          <td> 😃 </td>
        </tr>
        <!--第5行 4节-->
        <tr>
          <td class="td1">
            4 <br />
            11:05~11:50
          </td>
          <!--周三-->
          <td> &#128516 </td>

          <!--周五-->
          <td> &#128516 </td>

        </tr>
        <!--第6行 5节-->
        <tr>
          <td class="td2">
            5 <br />
            2:00~2:45
          </td>

          <!--周一-->
          <td rowspan=2 class="c541"> 计算机基础<br />2-16周(双)<br />教1-201<br />数据库基础<br />7-17周(单)<br />JS-303</td>
          <!--周二-->
          <td rowspan=2>C#程序设计（123/4）<br />2-10,12-14周<br />三园区
            5-305 </td>
          <!--周三-->
          <td> &#128516 </td>
          <!--周四-->
          <td> &#128516 </td>
          <!--周五-->
          <td rowspan=2> C#程序设计(521-524)<br />2-5,7-10,12-15周<br />三园区5-401 </td>
        </tr>
        <!--第7行 6节-->
        <tr>
          <td class="td2">
            6 <br />
            2:55~3:40
          </td>
          <!--周三-->
          <td> &#128516 </td>
          <!--周四-->
          <td> &#128516 </td>

        </tr>
        <!--第8行 7节-->
        <tr>
          <td class="td2">
            7 <br />
            4:10~4:55
          </td>
          <!--周一-->
          <td rowspan=2 class="c141">
            计算机基础<br />5-16周<br />云实验室
          </td>
          <!--周二-->
          <td rowspan=2 class='c521'>网络编程 <br />5-10,12-17周<br />三园区5号楼301</td>
          <!--周三-->
          <td> </td>
          <!--周四-->
          <td></td>
          <!--周五-->
          <td></td>

        </tr>
        <!--第9行 8节-->
        <tr>
          <td class="td2">
            8 <br />
            5:05~5:50
          </td>
          <!--周三-->
          <td></td>
          <!--周四-->
          <td></td>
          <!--周五-->
          <td> </td>
        </tr>
        <!--第10行 9节-->
        <tr>
          <td class="td3">
            9 <br />
            7:00~7:45
          </td>
          <!--周一-->
          <td></td>
          <!--周二-->
          <td></td>
          <!--周三-->
          <td rowspan=2 class='c521'> 网络编程<br />1-10,12-17周<br />教1楼309</td>
          <!--周四-->
          <td> </td>
          <!--周五-->
          <td rowspan=2> C#程序设计(521-524)<br />2-10,12-14周<br />教1-309</td>
        </tr>
        <!--第11行 10节-->
        <tr>
          <td class="td3">
            10 <br />
            7:55~8:40
          </td>
          <!--周一-->
          <td> </td>
          <!--周二-->
          <td> </td>
          <!--周四-->
          <td> </td>

        </tr>
        <!--第12行-->
        <tr>
          <td>温馨提醒:</td>
          <td colspan="5">
            <div id="scrolling-text">今天是<span id="riqi"></span>2025年5月18日 星期日<span id="nongli"></span>农历四月二十一，本周是第<span
                id="week1">14</span>周，本学期还剩<span id="week2">5</span>周了，加油哦！💪 </div>
          </td>
        </tr>
      </table>
    </div>
  </div>
</template>

<script setup>
import Header from '../components/Header.vue';
import { ref } from 'vue'

function getweek() {
  var week = -1;
  var riQi;
  var festival = "";//节日
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  const day = now.getDate();
  riQi = year + "年" + month + "月" + day + "日";

  //具体是第几周要参考真实的校历
  if (month == 2) {
    if (day >= 16 && day <= 22) week = 1;
    if (day >= 23 && day <= 28) week = 2;
  } else if (month == 3) {
    if (day == 1) week = 2;
    if (day >= 2 && day <= 8) week = 3;
    if (day >= 9 && day <= 15) week = 4;
    if (day >= 16 && day <= 22) week = 5;
    if (day >= 13 && day <= 29) week = 6;
    if (day >= 30 && day <= 31) week = 7;
  } else if (month == 4) {
    if (day == 4) festival = " 清明节";

    if (day >= 1 && day <= 5) week = 7;
    if (day >= 6 && day <= 12) week = 8;
    if (day >= 13 && day <= 19) week = 9;
    if (day >= 20 && day <= 26) week = 10;
    if (day >= 27 && day <= 30) week = 11;
  } else if (month == "5") {

    if (day >= 1 && day <= 3) week = 11;
    if (day >= 4 && day <= 10) week = 12;
    if (day >= 11 && day <= 17) week = 13;
    if (day >= 18 && day <= 24) week = 14;
    if (day >= 25 && day <= 31) week = 15;
    if (day == 31) festival = " 端午节";
  } else if (month == "6") {
    if (day >= 1 && day <= 7) week = 16;
    if (day >= 8 && day <= 14) week = 17;
    if (day >= 15 && day <= 21) week = 18;
    if (day >= 22 && day <= 28) week = 19;
    if (day >= 29 && day <= 30) week = 20;
  }
  else if (month == "7") {
    if (day >= 1 && day <= 5) week = 20;
  }
  else {
    week = -1;
  }

  if (week > 0) {
    document.getElementById("riqi").innerHTML = riQi + solarday() + festival;
    document.getElementById("week1").innerHTML = week;
    document.getElementById("week2").innerHTML = 19 - week;
  } else {
    document.getElementById("scrolling-text").innerHTML = "<span style='color:red'>本学期已结束，本课表作废!</span>";
  }

}


const lunarinfo = ref([19416, 19168, 42352, 21717, 53856, 55632, 91476, 22176, 39632, 21970, 19168, 42422, 42192, 53840, 119381, 46400, 54944, 44450, 38320, 84343, 18800, 42160, 46261, 27216, 27968, 109396, 11104, 38256, 21234, 18800, 25958, 54432, 59984, 28309, 23248, 11104, 100067, 37600, 116951, 51536, 54432, 120998, 46416, 22176, 107956, 9680, 37584, 53938, 43344, 46423, 27808, 46416, 86869, 19872, 42448, 83315, 21200, 43432, 59728, 27296, 44710, 43856, 19296, 43748, 42352, 21088, 62051, 55632, 23383, 22176, 38608, 19925, 19152, 42192, 54484, 53840, 54616, 46400, 46496, 103846, 38320, 18864, 43380, 42160, 45690, 27216, 27968, 44870, 43872, 38256, 19189, 18800, 25776, 29859, 59984, 27480, 21952, 43872, 38613, 37600, 51552, 55636, 54432, 55888, 30034, 22176, 43959, 9680, 37584, 51893, 43344, 46240, 47780, 44368, 21977, 19360, 42416, 86390, 21168, 43312, 31060, 27296, 44368, 23378, 19296, 42726, 42208, 53856, 60005, 54576, 23200, 30371, 38608, 19415, 19152, 42192, 118966, 53840, 54560, 56645, 46496, 22224, 21938, 18864, 42359, 42160, 43600, 111189, 27936, 44448])
const city = ref();
const info = ([]);
//*农历*
function lyeardays(a) {
  var b, c = 348;
  for (b = 32768; b > 8; b >>= 1) c += lunarinfo[a - 1900] & b ? 1 : 0;
  return c + leapdays(a)
}
function leapdays(a) {
  return leapmonth(a) ? lunarinfo[a - 1900] & 65536 ? 30 : 29 : 0
}
function leapmonth(a) {
  return lunarinfo[a - 1900] & 15
}
function monthdays(a, b) {
  return lunarinfo[a - 1900] & 65536 >> b ? 30 : 29
}
function lunar(a) {
  var b, c = 0,
    d = 0;
  c = new Date(1900, 0, 31);
  a = (a - c) / 864E5;
  c = c = "";
  mydate = new Date;
  c = mydate.getDay();
  if (c == 0) weekday = " \u661f\u671f\u65e5 ";
  else if (c == 1) weekday = " \u661f\u671f\u4e00 ";
  else if (c == 2) weekday = " \u661f\u671f\u4e8c ";
  else if (c == 3) weekday = " \u661f\u671f\u4e09 ";
  else if (c == 4) weekday = " \u661f\u671f\u56db ";
  else if (c == 5) weekday = " \u661f\u671f\u4e94 ";
  else if (c == 6) weekday = " \u661f\u671f\u516d ";
  this.daycyl = a + 40;
  this.moncyl = 14;
  for (b = 1900; b < 2050 && a > 0; b++) {
    d = lyeardays(b);
    a -= d;
    this.moncyl += 12
  }
  if (a < 0) {
    a += d;
    b--;
    this.moncyl -= 12
  }
  this.year = b;
  this.yearcyl = b - 1864;
  c = leapmonth(b);
  this.isleap = false;
  for (b = 1; b < 13 && a > 0; b++) {
    if (c > 0 && b == c + 1 && this.isleap == false) {
      --b;
      this.isleap = true;
      d = leapdays(this.year)
    } else d = monthdays(this.year, b);
    if (this.isleap == true && b == c + 1) this.isleap = false;
    a -= d;
    this.isleap == false && this.moncyl++
  }
  if (a == 0 && c > 0 && b == c + 1) if (this.isleap) this.isleap = false;
  else {
    this.isleap = true; --b; --this.moncyl
  }
  if (a < 0) {
    a += d; --b; --this.moncyl
  }
  this.month = b;
  this.day = a + 1
}
function cday(a, b) {
  var c = new Array("\u65e5", "\u4e00", "\u4e8c", "\u4e09", "\u56db", "\u4e94", "\u516d", "\u4e03", "\u516b", "\u4e5d", "\u5341"),
    d = new Array("\u521d", "\u5341", "\u5eff", "\u5345", "\u3000");
  a = a > 10 ? "\u5341" + c[a - 10] : c[a];
  a += "\u6708";
  if (a == "\u5341\u4e8c\u6708") a = "\u814a\u6708";
  if (a == "\u4e00\u6708") a = "\u6b63\u6708";
  //alert(Math.floor(b));
  switch (Math.floor(b)) {
    case 1: a += "\u521d\u4e00"; break; case 2: a += "\u521d\u4e8c"; break;
    case 3: a += "\u521d\u4e09"; break; case 4: a += "\u521d\u56db"; break;
    case 5: a += "\u521d\u4e94"; break; case 6: a += "\u521d\u516d"; break;
    case 7: a += "\u521d\u4e03"; break; case 8: a += "\u521d\u516b"; break;
    case 9: a += "\u521d\u4e5d"; break; case 10: a += "\u521d\u5341"; break;
    case 11: a += "\u5341\u4e00"; break; case 12: a += "\u5341\u4e8c"; break;
    case 13: a += "\u5341\u4e09"; break; case 14: a += "\u5341\u56db"; break;
    case 15: a += "\u5341\u4e94"; break; case 16: a += "\u5341\u516d"; break;
    case 17: a += "\u5341\u4e03"; break; case 18: a += "\u5341\u516b"; break;
    case 19: a += "\u5341\u4e5d"; break; case 20: a += "\u4e8c\u5341"; break;
    case 21: a += "\u4e8c\u5341\u4e00"; break;
    case 22: a += "\u4e8c\u5341\u4e8c"; break;
    case 23: a += "\u4e8c\u5341\u4e09"; break;
    case 24: a += "\u4e8c\u5341\u56db"; break;
    case 25: a += "\u4e8c\u5341\u4e94"; break;
    case 26: a += "\u4e8c\u5341\u516d"; break;
    case 27: a += "\u4e8c\u5341\u4e03"; break;
    case 28: a += "\u4e8c\u5341\u516b"; break;
    case 29: a += "\u4e8c\u5341\u4e5d"; break;
    case 30: a += "\u4e09\u5341"; break;
    case 31: a += "\u4e09\u5341\u4e00"; break;
    default: a += d[Math.floor(b / 10)]; a += c[b % 10]
  }
  return a
}
function solarday() {
  var now = new Date();
  var a = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  a = new lunar(a);
  var b = "";
  a = cday(a.month, a.day);
  return (weekday + " 农历" + a);
}

function openWin() {
  OpenWindow = window.open("", "newwin", "height=200, width=300,top=20,left=" + window.screen.availWidth, "toolbar=no ,scrollbars=" + scroll + ",menubar=no");

  //写成一行
  OpenWindow.document.write("<TITLE>教学安排</TITLE>")
  OpenWindow.document.write("<BODY BGCOLOR=#ffffff>")
  OpenWindow.document.write("<h3>本学期教学安排如下：</h3>")
  OpenWindow.document.write("开始上课：2025.2.17<br/>")
  OpenWindow.document.write("</BODY>")
  OpenWindow.document.write("</HTML>")
  OpenWindow.document.close()
}

function On1() {
  let self = this;
  var native = new BMap.LocalCity();
  // var city;	
  native.get(function (r) {
    c = r.name;
    if (c == "全国") {
      alert("定位失败，请手动输入城市")
      self.srch("北京");//定位失败则返回北京天气
      self.city = c;//更新input控件的value值
    }
    //调用自定义的获取天气的函数
    self.srch(c);
    self.city = c;//更新input控件的value值		
  })
}

function srch(c) {
			
      // 保存 this
              let self = this;
             //第1次发送ajax请求，获取城市ID
        let result;
        let CityId;
        let xhr = new XMLHttpRequest();
        
        xhr.open("get", "https://geoapi.qweather.com/v2/city/lookup?location="+c+ "&key=28ea751944f44b19a8041d0325f1eace");
               xhr.send(null);
       
            xhr.onreadystatechange = function() {
            if (xhr.readyState == 4) {
            if (xhr.status == 200) {
           //在这里接收响应数据
           result = xhr.responseText;			
     CityId=JSON.parse(result).location[0].id;			
   
     //第2次发送ajax请求，获取天气信息
   let xhr1 = new XMLHttpRequest();
   xhr1.open("get", "https://devapi.qweather.com/v7/weather/3d?location="+CityId+"&key=28ea751944f44b19a8041d0325f1eace");		
       xhr1.send(null);		
   xhr1.onreadystatechange = function() {
        if (xhr1.readyState == 4) {
            if (xhr1.status == 200) {
      //在这里接收响应数据
           let  result1 = JSON.parse(xhr1.responseText);		
           self.info=result1.daily;				
     //alert(info);
     self.city=c;//更新input控件的value值
              }
           }
      }			
              }
           }
         }		
 }
</script>

<style>
.td1 {
  border: 1px solid black;
  width: 160px;
  height: 30px;
  text-align: center;
  background-color: green;
}

.td2 {
  border: 1px solid black;
  width: 160px;
  height: 30px;
  text-align: center;
  background-color: magenta;
}

.td3 {
  border: 1px solid black;
  width: 160px;
  height: 30px;
  text-align: center;
  background-color: #FFA500;
}

td {
  border: 1px solid black;
  width: 160px;
  height: 30px;
  text-align: center;
}

th {
  border: 1px solid black;
}

table {
  float: left;
  border-collapse: collapse;
  border: 2px solid #000080;
  margin-left: 20px;
}

caption {
  font-weight: bold;
  margin-bottom: .5em;
}

tr {

  align: center;
}

#riqi {
  color: red;
}

#week1 {
  color: red;
  display: inline-block;
  width: 30px;
  text-align: center;
}

#week2 {
  color: red;
  display: inline-block;
  width: 30px;
  text-align: center;
}

#blue {
  color: blue;
  bold: ture
}

#red {
  color: red;
  bold: ture
}

.c941 {
  background-color: #F2ED75;
  align: center;
}

.c141 {
  background-color: #C7EDCC;
  align: center;
}

.c121 {
  background-color: #DDA0DD;
  align: center;
}

.c541 {
  background-color: #D8D8D8;
  align: center;
}

.c521 {
  background-color: #F5DEB3;
  align: center;
}

#scrolling-text {
  /*  border:3px solid red; */
  text-align: right;
  white-space: nowrap;
  overflow: hidden;
  width: 705px;
  animation: scrolling 4s linear infinite;
}

@keyframes scrolling {
  0% {
    transform: translateX(14%);
  }

  100% {
    transform: translateX(1%);
  }
}

/*------------天气样式----------------*/
.weather_list {
  float: left;
  /*border:1px solid green;*/
  height: 500px;
  width: 100px;
  text-align: left;
  margin-top: 60px;

}

.weather_list li {
  /*border:2px solid blue;*/
  display: block;
  width: 100px;
  height: 160px;
  padding: 0px 0px;

  overflow: hidden;
  position: relative;
  margin-left: -30px;

}

.weather_list li:last-child {
  background: none;
}

.info_type {
  /*border:1px solid yellow;   */
  line-height: 20px;
  color: #996600;
  font-size: 15px;
  text-align: center;
}

.info_type span {
  line-height: 40px;
  /*background-color:pink;*/
  display: inline-block;
  vertical-align: middle;
  /*光指定height: 40px;不行*/
}

.info_date b {
  float: left;
  margin-left: 15px;
}

.info_time span {
  color: #9966FF;
  font-size: 15px;
  line-height: 20px;
}

.info_temp {
  font-size: 15px;
  color: #fda252;
}

.info_temp b {
  font-size: 15px;
}

.info_temp .low {
  color: #003366;
}

.info_temp .high {
  color: #993300;
}
</style>