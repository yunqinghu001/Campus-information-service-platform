<template>
    <Header></Header>
    
</template>

<script setup>
import Header from '../components/Header.vue';


</script>

<style>

</style>