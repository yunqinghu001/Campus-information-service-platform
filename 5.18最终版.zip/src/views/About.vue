<template>

  <Header></Header>

  <el-main>

    <body>

      <table>
        <tr>
          <td>
            <p>姓名：张三</p>
          </td>
        </tr>
        <tr>
          <td>性别：男</td>
        </tr>
        <tr>
          <td>年龄：19</td>
        </tr>
        <tr>
          <td>家乡：<a href="https://baike.baidu.com/item/%E5%AD%9D%E6%84%9F/163646?fr=aladdin">湖北省孝感市</a></td>
        </tr>
        <tr>
          <td>就读院校：<a href="http://www.hbeu.cn/" target="_blank">湖北工程学院</a></td>
        </tr>
        <tr>
          <td>就读专业：<a href="http://jsjxy.hbeu.cn/info/1046/2392.htm">计算机科学与技术</a></td>
        </tr>
        <tr>
          <td>学生证号：201614#######</td>
        </tr>
        <tr>
          <td>兴趣爱好：听歌，打篮球</td>
        </tr>
        <tr>
          <td>政治面貌：团员</td>
        </tr>
        <tr>
          <td>联系电话：13245676543</td>
        </tr>
        <tr>
          <td>Email:179997256@qq.com</td>
        </tr>

      </table>

      <div id="moveText">
        <marquee>
          <span>青春&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;奔放&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;活泼&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;热情</span>
        </marquee>
      </div>

      <div id="footer">版权所有&copy 张三 | 地址：湖北省孝感市交通大道272号 | 邮编：432003 | 反馈意见：123456@qq.com</div>

    </body>
  </el-main>
</template>

<script setup>
import Header from '../components/Header.vue';


</script>
