<template>


  <el-main>
    <el-link href="https://dblab.xmu.edu.cn/post/352/" target="_blank">介绍</el-link>
  </el-main>
</template>

<script setup>
import Header from '../components/Header.vue';


</script>
