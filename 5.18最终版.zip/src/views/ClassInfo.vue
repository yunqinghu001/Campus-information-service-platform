<template>
    <el-container class="layout-container-demo" style="height: 100%;width: 100%;">
        <el-aside width="200px" style="height: 100vh; overflow: hidden">
            <el-scrollbar>
                <el-menu :default-openeds="['1', '3']">
                    <el-sub-menu index="1">
                        <template #title>
                            <el-icon>
                                <message />
                            </el-icon>
                            <el-link href="\" @click.prevent="increment(1)">主页</el-link>
                        </template>


                    </el-sub-menu>

                    <el-sub-menu index="2">
                        <template #title>
                            <el-icon><icon-menu /></el-icon>
                            <el-link href="\ClassTable" @click.prevent="increment(2)">课表</el-link>
                        </template>

                    </el-sub-menu>

                    <el-sub-menu index="3">
                        <template #title>
                            <el-icon>
                                <setting />
                            </el-icon>
                            <el-link href="\Info" @click.prevent="increment(3)">个人介绍</el-link>
                        </template>

                    </el-sub-menu>
                </el-menu>
            </el-scrollbar>
        </el-aside>

        <el-container>
            <el-header style="text-align: right; font-size: 12px">
                <div class="toolbar">
                    <span>Lsy</span>
                </div>
            </el-header>

            <el-main>
                


            </el-main>
        </el-container>
    </el-container>
</template>

<script setup>
import { Menu as IconMenu, Message, Setting,Download } from '@element-plus/icons-vue'


</script>

<style scoped>
.layout-container-demo .el-header {
    position: relative;
    background-color: var(--el-color-primary-light-7);
    color: var(--el-text-color-primary);
}

.layout-container-demo .el-aside {
    color: var(--el-text-color-primary);
    background: var(--el-color-primary-light-8);
}

.layout-container-demo .el-menu {
    border-right: none;
}

.layout-container-demo .el-main {
    padding: 0;
}

.layout-container-demo .toolbar {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    right: 20px;
}

.container {
    width: 100%;
    height: 100vh;
    display: flex;
    flex-direction: column;
}

.header {
    width: 100%;
    height: 50px;
}

.content {
    width: 100%;
    flex: 1;
}

.footer {
    width: 100%;
    height: 50px;
}
</style>